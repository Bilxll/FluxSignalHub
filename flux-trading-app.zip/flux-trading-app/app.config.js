// app.config.js
// This single config file builds TWO different apps depending on the
// APP_VARIANT environment variable: "admin" or "receiver".
//
// Run with:
//   APP_VARIANT=admin   eas build --platform android --profile preview
//   APP_VARIANT=receiver eas build --platform android --profile preview
//
// Or for local dev:
//   APP_VARIANT=admin   npx expo start
//   APP_VARIANT=receiver npx expo start

const IS_ADMIN = process.env.APP_VARIANT === "admin";

const name = IS_ADMIN ? "FLUX Admin" : "FLUX Signals";
const slug = IS_ADMIN ? "flux-admin" : "flux-receiver";
const androidPackage = IS_ADMIN
  ? "com.fluxtraders.admin"
  : "com.fluxtraders.receiver";
const iosBundleId = IS_ADMIN
  ? "com.fluxtraders.admin"
  : "com.fluxtraders.receiver";

export default {
  expo: {
    name,
    slug,
    scheme: slug,
    version: "1.0.0",
    orientation: "portrait",
    icon: "./assets/logo.png",
    userInterfaceStyle: "light",
    splash: {
      image: "./assets/logo.png",
      resizeMode: "contain",
      backgroundColor: "#F7F2E7"
    },
    extra: {
      APP_VARIANT: IS_ADMIN ? "admin" : "receiver",
      eas: {
        projectId: "REPLACE-WITH-YOUR-EAS-PROJECT-ID"
      }
    },
    android: {
      package: androidPackage,
      adaptiveIcon: {
        foregroundImage: "./assets/logo.png",
        backgroundColor: "#F7F2E7"
      },
      permissions: ["NOTIFICATIONS", "INTERNET"],
      googleServicesFile: IS_ADMIN
        ? "./google-services.admin.json"
        : "./google-services.receiver.json"
    },
    ios: {
      bundleIdentifier: iosBundleId,
      supportsTablet: false,
      googleServicesFile: IS_ADMIN
        ? "./GoogleService-Info.admin.plist"
        : "./GoogleService-Info.receiver.plist"
    },
    plugins: [
      "expo-notifications"
    ]
  }
};

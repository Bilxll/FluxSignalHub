// src/firebase/firebaseConfig.js
//
// 1. Go to https://console.firebase.google.com -> create a project "FluxTraders"
// 2. Add a Web App (even though this is React Native, the JS SDK uses the web config)
// 3. Copy the config object it gives you and paste the values below
// 4. Enable Firestore (Build > Firestore Database > Create database)
// 5. Enable Authentication > Sign-in method > Email/Password (for the admin app)
// 6. (Optional but recommended) Also register an Android app + iOS app in the
//    same Firebase project to download google-services.json /
//    GoogleService-Info.plist for push notifications - see README.

import { initializeApp, getApps, getApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getAuth } from "firebase/auth";

const firebaseConfig = {
  apiKey: "REPLACE_ME",
  authDomain: "REPLACE_ME.firebaseapp.com",
  projectId: "REPLACE_ME",
  storageBucket: "REPLACE_ME.appspot.com",
  messagingSenderId: "REPLACE_ME",
  appId: "REPLACE_ME"
};

export const app = getApps().length ? getApp() : initializeApp(firebaseConfig);
export const db = getFirestore(app);
export const auth = getAuth(app);
